var SocketManager_8cpp =
[
    [ "_from", "de/dec/SocketManager_8cpp.html#a23a7414c4d5b67960a23333828a690ab", null ],
    [ "_to", "de/dec/SocketManager_8cpp.html#a6525dd0a7d52616a604e6765d0f3b332", null ]
];