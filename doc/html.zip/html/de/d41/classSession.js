var classSession =
[
    [ "xint", "de/d41/classSession.html#a0b8685b292daee1703ce6a73fb035ec5", null ],
    [ "xll", "de/d41/classSession.html#ac368ec25310b2123a9cd5294d632c1f8", null ],
    [ "xstring", "de/d41/classSession.html#ad891c4a2f459fe38d917fc7a0bd141f4", null ],
    [ "Session", "de/d41/classSession.html#a3e3a51293375f50f927a4d1dde725b7f", null ],
    [ "getAlive", "de/d41/classSession.html#af374968fe55fdd11990a39c2230697d5", null ],
    [ "getPriority", "de/d41/classSession.html#ae7052e11c9cb1f018f7644038b30ffc2", null ],
    [ "getToken", "de/d41/classSession.html#af5dc64cb18e7eb62369580e7f6869f2f", null ],
    [ "getUserid", "de/d41/classSession.html#a2de2201713d142901577616a118238d2", null ],
    [ "setAlive", "de/d41/classSession.html#a14f83cb9672f60f061151f840b2ca3f2", null ],
    [ "setPriority", "de/d41/classSession.html#aa7680e8edb087d8301ffa3bead1f9f84", null ],
    [ "setToken", "de/d41/classSession.html#aaafefbd74faf8c38eb795c6d258e5855", null ],
    [ "setUserid", "de/d41/classSession.html#a4998b04e8b8d24ed30e179b198a5c4f0", null ]
];