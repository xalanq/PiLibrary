var classListWidgetItemBook =
[
    [ "ListWidgetItemBook", "de/d50/classListWidgetItemBook.html#a51a7c1213e4bce4b29f6253d7da12724", null ],
    [ "getBook", "de/d50/classListWidgetItemBook.html#ad22729d1f7d6acf0c89460afbdf4114e", null ],
    [ "update", "de/d50/classListWidgetItemBook.html#ac7677cf12577366b9bb2bb40d9ebe0a8", null ]
];