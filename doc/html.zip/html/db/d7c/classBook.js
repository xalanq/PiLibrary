var classBook =
[
    [ "cleanCover", "db/d7c/classBook.html#a1e5c6556ff5b6a352c33bec27898667e", null ],
    [ "getAmount", "db/d7c/classBook.html#a7aea100844a0ff0c81c1ec61fdd6a775", null ],
    [ "getPosition", "db/d7c/classBook.html#ac28095972d9e1c8e25a9be9c61720d59", null ],
    [ "setAmount", "db/d7c/classBook.html#afa9837203a3164f6bc9e5003ad47d9ef", null ],
    [ "setFromPtree", "db/d7c/classBook.html#a9409552e427f74689213fdc55cf4c3c1", null ],
    [ "setPosition", "db/d7c/classBook.html#aa4d09b4f9f3ef8baea4c67744f4297f6", null ],
    [ "updateFromPtree", "db/d7c/classBook.html#a4ee7700309e7d1e82b43573a903fb35a", null ]
];