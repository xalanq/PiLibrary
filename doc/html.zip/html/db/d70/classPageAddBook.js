var classPageAddBook =
[
    [ "PageAddBook", "db/d70/classPageAddBook.html#a5590dc0374a03c638cc7e7fd9bb3e47b", null ],
    [ "slotAdd", "db/d70/classPageAddBook.html#a791e15417ddb805058a33e0e10f9b386", null ],
    [ "slotAddEnd", "db/d70/classPageAddBook.html#a5cac8403846118dbe499205f0277cbd6", null ]
];