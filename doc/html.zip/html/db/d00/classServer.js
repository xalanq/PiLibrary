var classServer =
[
    [ "error_code", "db/d00/classServer.html#a1c8ae1fdea2b36ef2149c8015ecef8a4", null ],
    [ "ptree", "db/d00/classServer.html#ac4962e435715d4e8158aff4f072b134d", null ],
    [ "system_error", "db/d00/classServer.html#a190dfa574a89847fd5cf11d2b32c67b6", null ],
    [ "xint", "db/d00/classServer.html#a75375971f9226a1683a029af34ae00f3", null ],
    [ "xll", "db/d00/classServer.html#a80833682fc5f0f9114b05604ec7442de", null ],
    [ "xstring", "db/d00/classServer.html#a3a1dfc755400447df4d9f9710071ff9c", null ],
    [ "Server", "db/d00/classServer.html#a9bdf7c0d043d630593467e3d59eac58d", null ]
];