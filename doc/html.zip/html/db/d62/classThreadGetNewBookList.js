var classThreadGetNewBookList =
[
    [ "ThreadGetNewBookList", "db/d62/classThreadGetNewBookList.html#a65a9dd75915146c70c912606c96cc86f", null ],
    [ "done", "db/d62/classThreadGetNewBookList.html#ac9809b549c68a29e08d57c60fbedac10", null ]
];