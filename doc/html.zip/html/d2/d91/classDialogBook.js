var classDialogBook =
[
    [ "DialogBook", "d2/d91/classDialogBook.html#a89a9cf7a7fa50b9e9b248f738c7d67b1", null ],
    [ "setBook", "d2/d91/classDialogBook.html#abfeca80b9e6d7e153511f42740178f51", null ],
    [ "signalModify", "d2/d91/classDialogBook.html#a35a1b572fe732e9b48a070666fd61b38", null ],
    [ "slotBorrowBegin", "d2/d91/classDialogBook.html#a3b445e657d9c0155c20fa9ceac6e1cf9", null ],
    [ "slotBorrowEnd", "d2/d91/classDialogBook.html#a7c101156212947478213630b1dca8883", null ],
    [ "slotModify", "d2/d91/classDialogBook.html#a621f2ea602b74f542053a32c0b86207c", null ],
    [ "slotMore", "d2/d91/classDialogBook.html#a1475a1211659dfe9cb4012b92b212215", null ],
    [ "slotStarBegin", "d2/d91/classDialogBook.html#ab9ee54f58cc2b7f3a376cd2ee101b65d", null ],
    [ "slotStarEnd", "d2/d91/classDialogBook.html#a563056c12a09a3d90fd6b9515a1d4449", null ]
];