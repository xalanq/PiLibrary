var classPageFavorite =
[
    [ "PageFavorite", "d2/d27/classPageFavorite.html#a07d4cc04db8239ddbafcadad33e601af", null ],
    [ "refresh", "d2/d27/classPageFavorite.html#ad8bdf5dcc528f07ba12cffa5b42934f5", null ],
    [ "signalModify", "d2/d27/classPageFavorite.html#a88a38a1867084c5a4118f9e9629bc30b", null ],
    [ "signalReady", "d2/d27/classPageFavorite.html#a1cee520ee4438cde41448ad25668f1c8", null ],
    [ "slotGetStarRecord", "d2/d27/classPageFavorite.html#a4420f62d9d2ae19768befcff92da541e", null ],
    [ "slotItemClicked", "d2/d27/classPageFavorite.html#a7e4997ec85d100082bebf8078d70c1c7", null ],
    [ "updateStar", "d2/d27/classPageFavorite.html#af16585520760ec0140d9fd3342d9d618", null ]
];