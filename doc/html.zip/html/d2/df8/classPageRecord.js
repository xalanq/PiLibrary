var classPageRecord =
[
    [ "PageRecord", "d2/df8/classPageRecord.html#a405e576324b8e078a1179d1b5d41f939", null ],
    [ "refresh", "d2/df8/classPageRecord.html#a849d7e6324b0cb370bda52c52f28845f", null ],
    [ "refreshBorrowRecord", "d2/df8/classPageRecord.html#a8aaef0c768740db46f6de5d0bde6b96a", null ],
    [ "refreshBrowseRecord", "d2/df8/classPageRecord.html#aba18a25317dd15069ae8dd414cb843f0", null ],
    [ "refreshKeepRecord", "d2/df8/classPageRecord.html#a6544ab42948d76d7aedd977cf7d32239", null ],
    [ "refreshLoginRecord", "d2/df8/classPageRecord.html#a190c5abe17facf0f39542942d53d9449", null ],
    [ "signalModify", "d2/df8/classPageRecord.html#a13ea966b57c8cf84abc65f12ecfedbda", null ],
    [ "signalReady", "d2/df8/classPageRecord.html#a47714f941ef5b56ddea914e6a54f108d", null ],
    [ "slotBorrowRecordItemClicked", "d2/df8/classPageRecord.html#a84ac103f4b8eb0183bcd58a1aff8830a", null ],
    [ "slotBrowseRecordItemClicked", "d2/df8/classPageRecord.html#a9c975c561ed714e18b6bbb002fd5b354", null ],
    [ "slotGetBorrowRecord", "d2/df8/classPageRecord.html#a1ba6d6a7a0559b63c2a9820f7e0028bc", null ],
    [ "slotGetBrowseRecord", "d2/df8/classPageRecord.html#ac38f4fe532640445d7b83fd76f8e704a", null ],
    [ "slotGetKeepRecord", "d2/df8/classPageRecord.html#ae7d7a4d3d56568792347dc6b6d3d1331", null ],
    [ "slotGetLoginRecord", "d2/df8/classPageRecord.html#adc6b202e3ac2e10ac69033a2fca73d52", null ],
    [ "slotKeepRecordItemClicked", "d2/df8/classPageRecord.html#a2c8f55cb6e46b73dee52f275beef6f48", null ],
    [ "updateBorrow", "d2/df8/classPageRecord.html#a34cbb78f9cf703b2d9eb80228e89acd1", null ],
    [ "updateBrowse", "d2/df8/classPageRecord.html#a88d7c050fcdd6e76816f8b45d38d1f44", null ]
];