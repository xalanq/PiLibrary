var classGetBrowseRecords =
[
    [ "GetBrowseRecords", "d2/de8/classGetBrowseRecords.html#ae2d74f228edaa10ddee14f12bd582096", null ],
    [ "done", "d2/de8/classGetBrowseRecords.html#abdbe7c1b2c0d3d6d4c82b6c1ee52c75f", null ],
    [ "slotEnd", "d2/de8/classGetBrowseRecords.html#a538f9e9030f63421c91a4a9c0baf9444", null ],
    [ "start", "d2/de8/classGetBrowseRecords.html#a6f3b163020ef45456706895f0e72d7dc", null ]
];