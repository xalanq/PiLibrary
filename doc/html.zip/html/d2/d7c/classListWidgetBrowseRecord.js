var classListWidgetBrowseRecord =
[
    [ "ListWidgetBrowseRecord", "d2/d7c/classListWidgetBrowseRecord.html#ac885a3b9492326e5d660bf51c73b45d5", null ],
    [ "add", "d2/d7c/classListWidgetBrowseRecord.html#a3ae839c00f9ab4d101bd2c11c9cf7e1c", null ],
    [ "update", "d2/d7c/classListWidgetBrowseRecord.html#a251ccb84a16f59b555c05712bcf0283a", null ]
];