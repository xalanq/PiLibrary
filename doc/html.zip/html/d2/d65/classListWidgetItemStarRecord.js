var classListWidgetItemStarRecord =
[
    [ "ListWidgetItemStarRecord", "d2/d65/classListWidgetItemStarRecord.html#a98fb276e0bbd41ff1678030fda08be23", null ],
    [ "getBook", "d2/d65/classListWidgetItemStarRecord.html#a4f0611b11b5635b85da066254da2d3da", null ],
    [ "update", "d2/d65/classListWidgetItemStarRecord.html#ab27e9f2f15f19d3f6dcf432858a5bfd4", null ]
];