var classListWidgetStarRecord =
[
    [ "ListWidgetStarRecord", "d2/ddd/classListWidgetStarRecord.html#a782cbb950cb108fd517487492e86dd34", null ],
    [ "add", "d2/ddd/classListWidgetStarRecord.html#a63376680e37093981b368f819e5bbf34", null ],
    [ "update", "d2/ddd/classListWidgetStarRecord.html#a8b1734222cc748f4afcbd800a19144d6", null ]
];