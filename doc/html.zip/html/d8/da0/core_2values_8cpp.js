var core_2values_8cpp =
[
    [ "AUTHOR", "d8/da0/core_2values_8cpp.html#a534c51728da95b5a6d0bca9b963090b4", null ],
    [ "EMAIL", "d8/da0/core_2values_8cpp.html#a9dc4940678f26b73cde488bbd96b2f70", null ],
    [ "GITHUB", "d8/da0/core_2values_8cpp.html#aa2101664ac688683518e8cb01c79bfe8", null ],
    [ "WEBSITE", "d8/da0/core_2values_8cpp.html#a6ae8fd949d03b023d8d23519bf046eb7", null ]
];