var classPageSetting =
[
    [ "PageSetting", "d8/d97/classPageSetting.html#a8f92a1b54ce411ab27416f251a510a50", null ],
    [ "signalLogout", "d8/d97/classPageSetting.html#a88d6ec836d0f63c47f79de2c1d41dbc5", null ],
    [ "signalModifyUser", "d8/d97/classPageSetting.html#ae7a1cf8be1eead02b78315fb653643d9", null ],
    [ "signalRefresh", "d8/d97/classPageSetting.html#a21a0f3d15f645ff9f75181ee9ca41814", null ],
    [ "slotChangeLanguage", "d8/d97/classPageSetting.html#a4f31de20341e2c23ecc13d1639b4ec6d", null ],
    [ "slotLogout", "d8/d97/classPageSetting.html#a6f6732da298a806bffed48b8897ddd8b", null ],
    [ "slotModify", "d8/d97/classPageSetting.html#afad2f8f0dfb5a2cdd2f03c17123b2d90", null ]
];