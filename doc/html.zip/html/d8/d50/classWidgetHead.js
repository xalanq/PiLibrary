var classWidgetHead =
[
    [ "WidgetHead", "d8/d50/classWidgetHead.html#a9ceaeea93d841f4fbfc141b2801679d7", null ],
    [ "slotModify", "d8/d50/classWidgetHead.html#a10025321d3b75d996de7ddd0f6604b89", null ]
];