var classThreadStarBook =
[
    [ "ThreadStarBook", "d8/da3/classThreadStarBook.html#a20b6c22fec493229c8ccb62e41e908e0", null ],
    [ "done", "d8/da3/classThreadStarBook.html#ae90e73ff4e59dceeba3d97a253acaf74", null ]
];