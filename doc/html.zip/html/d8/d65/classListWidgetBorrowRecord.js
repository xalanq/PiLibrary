var classListWidgetBorrowRecord =
[
    [ "ListWidgetBorrowRecord", "d8/d65/classListWidgetBorrowRecord.html#ac28da1abbcef0d48946120dc7d25208b", null ],
    [ "add", "d8/d65/classListWidgetBorrowRecord.html#a9f9d0bd42b9d4e66e1e0d8efcc698781", null ],
    [ "update", "d8/d65/classListWidgetBorrowRecord.html#a4baa4bc3817d114c2f63a25b1f687eaf", null ]
];