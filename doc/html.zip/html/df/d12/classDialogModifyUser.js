var classDialogModifyUser =
[
    [ "DialogModifyUser", "df/d12/classDialogModifyUser.html#a1ff543c998b0b73f7056f83ad9e9c663", null ],
    [ "slotModifyBegin", "df/d12/classDialogModifyUser.html#ad218eabca6dcff87ecad2f2c8553b597", null ],
    [ "slotModifyEnd", "df/d12/classDialogModifyUser.html#a7e9367a9cbf62dc3d35f0d34031d4e00", null ]
];