var classPageBrowse =
[
    [ "PageBrowse", "dc/dfe/classPageBrowse.html#a94eccb950acf8e8b50c3a0ca71f984f1", null ],
    [ "refresh", "dc/dfe/classPageBrowse.html#a57208f8e8a0df8078996978d48c33593", null ],
    [ "signalModify", "dc/dfe/classPageBrowse.html#a6ed6d7c79d381a9fe81ff89fcd43b868", null ],
    [ "signalReady", "dc/dfe/classPageBrowse.html#a77f41aa73d06934c514c1be59a559524", null ],
    [ "slotReady", "dc/dfe/classPageBrowse.html#a0a145b7958906ca76d5fc047e8c7355b", null ],
    [ "slotSearch", "dc/dfe/classPageBrowse.html#a0029e52f2261aba9f34bdb3f1b5c7d33", null ],
    [ "updateStar", "dc/dfe/classPageBrowse.html#a306d4ee2c624851f19ef9156f5fe96ab", null ]
];