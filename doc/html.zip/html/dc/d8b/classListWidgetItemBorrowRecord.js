var classListWidgetItemBorrowRecord =
[
    [ "ListWidgetItemBorrowRecord", "dc/d8b/classListWidgetItemBorrowRecord.html#a82a40292014159860d8c8d3ee2558d27", null ],
    [ "getBook", "dc/d8b/classListWidgetItemBorrowRecord.html#aedef6af0bba1a714af84616db30b012d", null ],
    [ "update", "dc/d8b/classListWidgetItemBorrowRecord.html#a7a2354439e570ef8bfd7ccd0ffa4f1c3", null ]
];