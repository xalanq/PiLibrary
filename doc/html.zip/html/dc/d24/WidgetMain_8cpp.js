var WidgetMain_8cpp =
[
    [ "NoMargin", "dc/d24/WidgetMain_8cpp.html#a53a18347db9b5b8c4e8fa56d9cc80895", null ]
];