var classThreadGetRecord =
[
    [ "ThreadGetRecord", "d7/d6c/classThreadGetRecord.html#a71a4164181c5d80e88b15a4a622dd56e", null ],
    [ "done", "d7/d6c/classThreadGetRecord.html#aed14359af8b69a4eceb95cfa3043ccf9", null ]
];