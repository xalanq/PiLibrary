var classKeepRecord =
[
    [ "ptree", "d7/d31/classKeepRecord.html#aff57fe32d986da322e4e4aa4c3b9fc16", null ],
    [ "xint", "d7/d31/classKeepRecord.html#aaae02d00bed614c022b5156ab8b01bb3", null ],
    [ "xll", "d7/d31/classKeepRecord.html#a2a3640dc24d6e0a3a237b2314bb09af3", null ],
    [ "xstring", "d7/d31/classKeepRecord.html#a93b5be899b18a4daaa5f16bb3ef93a17", null ],
    [ "~KeepRecord", "d7/d31/classKeepRecord.html#a0d4bb8de4345ded7ca5a5f33b29f464e", null ],
    [ "getBeginTime", "d7/d31/classKeepRecord.html#a825e39ecf75dc8eb2f043091160698e8", null ],
    [ "getBookid", "d7/d31/classKeepRecord.html#af003e1540767b64c19ace9b891c8434e", null ],
    [ "getEndTime", "d7/d31/classKeepRecord.html#a866a2ae40167faa2f0fe4a47eeedcfce", null ],
    [ "operator<", "d7/d31/classKeepRecord.html#a8d27cb704be8665cbc444709851c4723", null ],
    [ "setBeginTime", "d7/d31/classKeepRecord.html#a4d17594facdaee91330fae78b56e2c1c", null ],
    [ "setBookid", "d7/d31/classKeepRecord.html#a8bd07adb730ea6395855cbda04c59e53", null ],
    [ "setEndTime", "d7/d31/classKeepRecord.html#a850da11799be6fb06426839b1268ffc3", null ],
    [ "setFromPtree", "d7/d31/classKeepRecord.html#aed662b17c8ad5325d88c84acfbb854b3", null ],
    [ "setTime", "d7/d31/classKeepRecord.html#a783dc2b924fab8ad45a4937c38757079", null ]
];