var classWidgetSearchBook =
[
    [ "WidgetSearchBook", "d7/dda/classWidgetSearchBook.html#acf8355d7adb5d672bbd76350a98469c6", null ],
    [ "searchInfo", "d7/dda/classWidgetSearchBook.html#a4c777237f9b8f3996191504509f25ace", null ],
    [ "slotMore", "d7/dda/classWidgetSearchBook.html#a108f0e80957056fd8142284719fa54f2", null ],
    [ "slotSearch", "d7/dda/classWidgetSearchBook.html#ad8b1f9d57ef48f5d7688261a404924e8", null ]
];