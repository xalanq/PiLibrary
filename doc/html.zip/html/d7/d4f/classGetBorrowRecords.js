var classGetBorrowRecords =
[
    [ "GetBorrowRecords", "d7/d4f/classGetBorrowRecords.html#abe9fee3b2d2e85b25a0782c52cee11d4", null ],
    [ "done", "d7/d4f/classGetBorrowRecords.html#ae124461e51b7d016d3ebe6429cfd95fe", null ],
    [ "slotEnd", "d7/d4f/classGetBorrowRecords.html#a3a094d2416f7bfef8767a69da42d6c1f", null ],
    [ "start", "d7/d4f/classGetBorrowRecords.html#a5e8f9960fe79a036d53dfb7844312fb0", null ]
];