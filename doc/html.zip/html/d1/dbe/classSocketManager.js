var classSocketManager =
[
    [ "ActionCode", "d1/dbe/classSocketManager.html#ac9ccaa52312adc73d880ccd32d16d7f9", null ],
    [ "error_code", "d1/dbe/classSocketManager.html#a7b0192ce960f01b3b5abbd3cf407f72d", null ],
    [ "ErrorCode", "d1/dbe/classSocketManager.html#a3a92671b063bf64c3c7416c2d29dae98", null ],
    [ "ptree", "d1/dbe/classSocketManager.html#a866a8d1f5189e70bc63c540e4aaf33f6", null ],
    [ "system_error", "d1/dbe/classSocketManager.html#a8c9ea30fbaf6b9bec5e53578f763c28c", null ],
    [ "xint", "d1/dbe/classSocketManager.html#a899b634df0e530a0502838173d46c453", null ],
    [ "xll", "d1/dbe/classSocketManager.html#a654d996d726b90283cf6a6793e82bb07", null ],
    [ "xstring", "d1/dbe/classSocketManager.html#a8674609cf31e25ee88b8e20c012a4a20", null ],
    [ "SocketManager", "d1/dbe/classSocketManager.html#a4fb960cb7413866da4c8b18af3942834", null ],
    [ "start", "d1/dbe/classSocketManager.html#a585e1a65746274a0fcd9166b21e9c113", null ],
    [ "stop", "d1/dbe/classSocketManager.html#a9ce350a6d30987b8bf70efcfb9fb6a95", null ]
];