var classGetStarRecords =
[
    [ "GetStarRecords", "d1/dc0/classGetStarRecords.html#a53f26222975e72eb8fe44d7f77da5a32", null ],
    [ "done", "d1/dc0/classGetStarRecords.html#a17837e7241172e34a8fd0cbd7bb69ef2", null ],
    [ "slotEnd", "d1/dc0/classGetStarRecords.html#a3dc4aec5860ebd9db443e80cc315ce8c", null ],
    [ "start", "d1/dc0/classGetStarRecords.html#a979d815c55aa724ae67f7a25e63b6f19", null ]
];