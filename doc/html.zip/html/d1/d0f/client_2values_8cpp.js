var client_2values_8cpp =
[
    [ "APP_NAME", "d1/d0f/client_2values_8cpp.html#abfcb08221d7a4796236552ec449a6087", null ],
    [ "ORG_NAME", "d1/d0f/client_2values_8cpp.html#ae22b60e3b6615f8404decc0174b73bba", null ],
    [ "saltBegin", "d1/d0f/client_2values_8cpp.html#a0696747ce8a92c0c6c097b5fc1027594", null ],
    [ "saltEnd", "d1/d0f/client_2values_8cpp.html#a3a52d8ebea0c6b4e6c5ea53d20236707", null ],
    [ "VERSION", "d1/d0f/client_2values_8cpp.html#a03322089084622af025278521131627d", null ]
];