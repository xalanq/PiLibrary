var classThreadSetPriority =
[
    [ "ThreadSetPriority", "d1/d25/classThreadSetPriority.html#ad117d62e604e1ff52bdefafc31ea72b1", null ],
    [ "done", "d1/d25/classThreadSetPriority.html#a7fac458ba802990bbe66e53afa5ca918", null ]
];