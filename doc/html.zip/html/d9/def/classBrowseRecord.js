var classBrowseRecord =
[
    [ "ptree", "d9/def/classBrowseRecord.html#a4627eee62fd47c840d2660a8d2327313", null ],
    [ "xint", "d9/def/classBrowseRecord.html#a89a0c9991a95147c81ea260ebb26a43f", null ],
    [ "xll", "d9/def/classBrowseRecord.html#aa75fd1e6ac7c91310298adb19d6fd443", null ],
    [ "xstring", "d9/def/classBrowseRecord.html#a25a187714ff6a7cea0162e023f007b77", null ],
    [ "getBookid", "d9/def/classBrowseRecord.html#a20d13961b016b36e505e943fa8274ec3", null ],
    [ "getTime", "d9/def/classBrowseRecord.html#af3cdd5deb247fed0e76eb5ff3892565a", null ],
    [ "operator<", "d9/def/classBrowseRecord.html#aeba44870bd7a9e18730b6326d450e950", null ],
    [ "setBookid", "d9/def/classBrowseRecord.html#a4cf9e2ad6343d565ca18563527546775", null ],
    [ "setFromPtree", "d9/def/classBrowseRecord.html#a82ed35178df507582076626382904f13", null ],
    [ "setTime", "d9/def/classBrowseRecord.html#aafa9f2caff9763e7bb1719e3d369f95d", null ]
];