var classUser =
[
    [ "ptree", "d9/dc0/classUser.html#a82abfb50dff9fde054d4738ff079e2af", null ],
    [ "xint", "d9/dc0/classUser.html#aa4d08f4097aac44dab46d58695477e1e", null ],
    [ "xll", "d9/dc0/classUser.html#ad6acbdc3e78ffb85669f20654dd27b9f", null ],
    [ "xstring", "d9/dc0/classUser.html#aa1cd7bed19beb6be206871c4bcbb6328", null ],
    [ "~User", "d9/dc0/classUser.html#a634d7ad22c3d2b5fed35f71e10d98628", null ],
    [ "getEmail", "d9/dc0/classUser.html#a018d4ceab954dba0f3de46b43b467290", null ],
    [ "getNickname", "d9/dc0/classUser.html#a86a5448ac9ac0c7387ab8d8594ee73ec", null ],
    [ "getPriority", "d9/dc0/classUser.html#a3f097a69bc6d1437156f4accdb3bcab1", null ],
    [ "getUserid", "d9/dc0/classUser.html#af5eb8d38f3c810be92098e2bc7d91413", null ],
    [ "getUsername", "d9/dc0/classUser.html#a25009f1e79a009797194075b99fdc694", null ],
    [ "setEmail", "d9/dc0/classUser.html#a35b91d436f927502edec3fc1a2bd71e7", null ],
    [ "setFromPtree", "d9/dc0/classUser.html#aa4c2651b2df9ccde613377695a9e1f17", null ],
    [ "setNickname", "d9/dc0/classUser.html#a383911dfe90a6d14e4896f85316e81fe", null ],
    [ "setPriority", "d9/dc0/classUser.html#a7b83a0e05482eddfe5dffed073f7a899", null ],
    [ "setUserid", "d9/dc0/classUser.html#a7be3f1e01f036d11ae65ccfefb9a5386", null ],
    [ "setUsername", "d9/dc0/classUser.html#a88fb1cbac4b9428568bfe1303df0c373", null ]
];