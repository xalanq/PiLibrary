var classLoginRecord =
[
    [ "ptree", "d9/dcc/classLoginRecord.html#aab3880708cae78fb2f208b8017e61a88", null ],
    [ "xint", "d9/dcc/classLoginRecord.html#a6200843e6978e285c384bcd143c59c44", null ],
    [ "xll", "d9/dcc/classLoginRecord.html#aa45a8cae6f1d02d0e69e362901e149b2", null ],
    [ "xstring", "d9/dcc/classLoginRecord.html#a9df7de94423deed4a59ee6748aca8efb", null ],
    [ "getIp", "d9/dcc/classLoginRecord.html#ac3bfe8af96b44e139684bf9df45fcba0", null ],
    [ "getTime", "d9/dcc/classLoginRecord.html#abc9297352edce486675a678bd969e0c0", null ],
    [ "operator<", "d9/dcc/classLoginRecord.html#a2d1018b7b65a6ea563262b10507e3d27", null ],
    [ "setFromPtree", "d9/dcc/classLoginRecord.html#aea4810562ec1dc0c9330a3ca86b3d0c1", null ],
    [ "setIp", "d9/dcc/classLoginRecord.html#a343f555ec6be27404940bcb013af7733", null ],
    [ "setTime", "d9/dcc/classLoginRecord.html#a988a7246b570a0d85fd5a44643439a62", null ]
];