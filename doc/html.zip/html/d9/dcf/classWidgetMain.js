var classWidgetMain =
[
    [ "WidgetMain", "d9/dcf/classWidgetMain.html#a8de86e820694f53dcdc9428e64ebf821", null ],
    [ "loadSetting", "d9/dcf/classWidgetMain.html#a42c21a8ddfd2a367b30f1e62a86df3dd", null ],
    [ "refresh", "d9/dcf/classWidgetMain.html#a2e059386b6073e58495db19749a1510c", null ],
    [ "saveSetting", "d9/dcf/classWidgetMain.html#a192811a36d00fd9cae576a1f94bf831c", null ],
    [ "setEvents", "d9/dcf/classWidgetMain.html#a1f2419b6adad7d1fb3d7e761ea5ce8eb", null ],
    [ "signalLogout", "d9/dcf/classWidgetMain.html#a5e4a984a3568b85917eb1a4363a1c623", null ]
];