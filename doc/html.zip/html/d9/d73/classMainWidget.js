var classMainWidget =
[
    [ "MainWidget", "d9/d73/classMainWidget.html#af431a16b70f84c3b4ee3fb0168def6a2", null ],
    [ "loadSetting", "d9/d73/classMainWidget.html#a425d06f49591e64615c54210b7d9d3fa", null ],
    [ "refresh", "d9/d73/classMainWidget.html#ab4c6889e82cb136f40aca8248b1016c0", null ],
    [ "saveSetting", "d9/d73/classMainWidget.html#ac9b1f81da24af2245ea0014447916e07", null ],
    [ "setEvents", "d9/d73/classMainWidget.html#ae9074c2e55fa8aa45c62156e0678fff6", null ],
    [ "signalLogout", "d9/d73/classMainWidget.html#ae0fa68434f5c916e243a76105139b80b", null ]
];