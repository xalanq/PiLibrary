var classListWidgetItemKeepRecord =
[
    [ "ListWidgetItemKeepRecord", "dd/dfe/classListWidgetItemKeepRecord.html#a5c8ac8459e4ce3a758bdef0adb235dc1", null ],
    [ "getBook", "dd/dfe/classListWidgetItemKeepRecord.html#ae7bccbbffe62857d12d50eb601877f17", null ],
    [ "update", "dd/dfe/classListWidgetItemKeepRecord.html#a003158dfda06c76a3c0ba0e1b301e922", null ]
];