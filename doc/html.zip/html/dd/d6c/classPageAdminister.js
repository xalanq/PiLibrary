var classPageAdminister =
[
    [ "PageAdminister", "dd/d6c/classPageAdminister.html#a4ed81b4bf46939d2bd9d1042c7ab040b", null ],
    [ "signalReady", "dd/d6c/classPageAdminister.html#a659fe27fbf240c3787b1a45b2fa04c44", null ],
    [ "slotReturn", "dd/d6c/classPageAdminister.html#a03741f2f6dbad6c9aa89059241ac8878", null ],
    [ "slotSetPriority", "dd/d6c/classPageAdminister.html#aa8c66e51d5124b6a313d35a11ecfa830", null ]
];