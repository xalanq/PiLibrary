var classDialogChooseTime =
[
    [ "DialogChooseTime", "dd/d63/classDialogChooseTime.html#ad0b7c31aeb2bd9930e19d90a067233ba", null ],
    [ "getKeepTime", "dd/d63/classDialogChooseTime.html#a8334d6ab94f46ebbcdaf6019c7d9064a", null ],
    [ "slotChanged", "dd/d63/classDialogChooseTime.html#a3122211e6c973e3a784181da9c4cf8ef", null ],
    [ "slotGo", "dd/d63/classDialogChooseTime.html#a4b565b92ef088b3a92c1c8d7c37413bd", null ]
];