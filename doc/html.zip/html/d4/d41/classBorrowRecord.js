var classBorrowRecord =
[
    [ "ptree", "d4/d41/classBorrowRecord.html#ad4aa54eb751a3887ddae7dd5c30bc472", null ],
    [ "xint", "d4/d41/classBorrowRecord.html#a4b850d716b2b69a59f57224202486651", null ],
    [ "xll", "d4/d41/classBorrowRecord.html#ae560bbc9eefb63d1c0152138ca3a6456", null ],
    [ "xstring", "d4/d41/classBorrowRecord.html#a7726907a411b8a281488e63b173fd1f4", null ],
    [ "~BorrowRecord", "d4/d41/classBorrowRecord.html#ae8406f880e3861a4c282500b8de8a956", null ],
    [ "getBeginTime", "d4/d41/classBorrowRecord.html#a50ed86f7109129096a5baacb257bff90", null ],
    [ "getBookid", "d4/d41/classBorrowRecord.html#a45a67169f7128160bede16450e514eaf", null ],
    [ "getEndTime", "d4/d41/classBorrowRecord.html#a26dd4166a77a0ed5023c58f579a8fe19", null ],
    [ "getReturnTime", "d4/d41/classBorrowRecord.html#a359a1b9a69da4f5e00a16803ec7d4f8a", null ],
    [ "operator<", "d4/d41/classBorrowRecord.html#aec1f65665fdc9b44f0464e4d263df5d3", null ],
    [ "setBeginTime", "d4/d41/classBorrowRecord.html#aecb2aa8adebcf97576a58595cc280f80", null ],
    [ "setBookid", "d4/d41/classBorrowRecord.html#acc162f8ebb73ada905cdceec4f7511b1", null ],
    [ "setEndTime", "d4/d41/classBorrowRecord.html#a7caac21ac0aa659fa554e2f8df235fde", null ],
    [ "setFromPtree", "d4/d41/classBorrowRecord.html#a2c064acb3169d9592045a58493d5bed6", null ],
    [ "setReturnTime", "d4/d41/classBorrowRecord.html#a5b66674710e25a6f12c18a8205259431", null ],
    [ "setTime", "d4/d41/classBorrowRecord.html#ad292ac1ea13b29d6d2dc2aa9f1299051", null ]
];