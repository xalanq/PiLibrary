var classSessionManager =
[
    [ "compareAlive", "db/dcc/structSessionManager_1_1compareAlive.html", "db/dcc/structSessionManager_1_1compareAlive" ],
    [ "compareToken", "da/d70/structSessionManager_1_1compareToken.html", "da/d70/structSessionManager_1_1compareToken" ],
    [ "compareUserid", "d7/d0e/structSessionManager_1_1compareUserid.html", "d7/d0e/structSessionManager_1_1compareUserid" ],
    [ "ptr", "d4/d5b/classSessionManager.html#aa57e83bf8dfbc16f4987835272852bac", null ],
    [ "xint", "d4/d5b/classSessionManager.html#a302909fc0f555eeaaa858076f2acd6ea", null ],
    [ "xll", "d4/d5b/classSessionManager.html#ae3de9f1aaa5927ed066c5d546513d990", null ],
    [ "xstring", "d4/d5b/classSessionManager.html#aa1a7bfcf0625c4e1089eba586197975c", null ],
    [ "SessionManager", "d4/d5b/classSessionManager.html#ae5e73c9f34d241b2ab68c72451a7ab47", null ],
    [ "add", "d4/d5b/classSessionManager.html#a220d05a515be86b4f3ba2cdd6e35ce73", null ],
    [ "add", "d4/d5b/classSessionManager.html#afa864f20506dfcc21eb6ccc8bc5f4ffc", null ],
    [ "add", "d4/d5b/classSessionManager.html#a1fc36ee77a398c67699efb9c0f445cf2", null ],
    [ "findToken", "d4/d5b/classSessionManager.html#a219a6e712153e7749e51b95c59dfa543", null ],
    [ "findUserid", "d4/d5b/classSessionManager.html#a112fce4015df71671d67b878d507a951", null ],
    [ "getDefaultAlive", "d4/d5b/classSessionManager.html#aa6e6c9fe08f465760d9c89a806ce9aa5", null ],
    [ "getRandToken", "d4/d5b/classSessionManager.html#a472c2de690c9e56e21b3218436a52f59", null ],
    [ "remove", "d4/d5b/classSessionManager.html#a9baa108f8d9e53d6db1a20350d9a9435", null ],
    [ "removeByToken", "d4/d5b/classSessionManager.html#a102e35440ece97f3e39af7a119a7de75", null ],
    [ "removeByUserid", "d4/d5b/classSessionManager.html#accea1ebc28d7ef4a0aadb6ca52e472dd", null ],
    [ "removeExpired", "d4/d5b/classSessionManager.html#a8d50ae05d6442735a0ced4433c67e39e", null ],
    [ "setAliveTime", "d4/d5b/classSessionManager.html#a0458f4f59432b2c535e2adecae8bd75d", null ]
];