var classGetKeepRecords =
[
    [ "GetKeepRecords", "d4/da1/classGetKeepRecords.html#a9979a079f154055096c0798576248bdb", null ],
    [ "done", "d4/da1/classGetKeepRecords.html#a76180043665e3ff0b0b9302d807af379", null ],
    [ "slotEnd", "d4/da1/classGetKeepRecords.html#afb01f17abb0cda1a7a3b01581d5d1f0a", null ],
    [ "start", "d4/da1/classGetKeepRecords.html#af868d832edb71f42930ef858199aed68", null ]
];