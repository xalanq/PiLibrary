var classWidgetModifyBook =
[
    [ "WidgetModifyBook", "d4/ddc/classWidgetModifyBook.html#a8b0cde337c54e63ae646760b6ea52065", null ],
    [ "signalModify", "d4/ddc/classWidgetModifyBook.html#aedfe03bf5f2ac2180408d4ff329179aa", null ],
    [ "slotModify", "d4/ddc/classWidgetModifyBook.html#a3fb919487ccaa1660b16180e6767fb2f", null ],
    [ "slotModifyEnd", "d4/ddc/classWidgetModifyBook.html#ab53c5c1a924e4b8ddb723ff61cbfdcdd", null ]
];