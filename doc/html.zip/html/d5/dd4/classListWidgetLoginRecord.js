var classListWidgetLoginRecord =
[
    [ "ListWidgetLoginRecord", "d5/dd4/classListWidgetLoginRecord.html#aaf8db9eceb3cb14f09b678fc2df427cb", null ],
    [ "add", "d5/dd4/classListWidgetLoginRecord.html#a20a503995e98bfcf8e0cf6281461c91e", null ]
];