var classDialogModifyBook =
[
    [ "DialogModifyBook", "d5/d4e/classDialogModifyBook.html#acd67bb80193dfdaa624ed8b52b4b782c", null ],
    [ "signalModify", "d5/d4e/classDialogModifyBook.html#a9afa349fb7b57dc56c90d2f0a5b84fbb", null ]
];