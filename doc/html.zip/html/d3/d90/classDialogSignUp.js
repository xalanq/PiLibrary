var classDialogSignUp =
[
    [ "DialogSignUp", "d3/d90/classDialogSignUp.html#a03c2299cb7c39a65815c772fff56ff03", null ],
    [ "slotSignUpBegin", "d3/d90/classDialogSignUp.html#a38d94ede7c4fbf3063f2bf95c0308ecf", null ],
    [ "slotSignUpEnd", "d3/d90/classDialogSignUp.html#a31b0be4d68b6cb582d3ded9f5f80ab2b", null ]
];