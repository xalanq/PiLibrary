var classWidgetLoginTitle =
[
    [ "WidgetLoginTitle", "d3/db6/classWidgetLoginTitle.html#a400ed4f29b195f6557a3fe0d240b120e", null ],
    [ "mouseMoveEvent", "d3/db6/classWidgetLoginTitle.html#a850b9ff644c14f1163e5667a7f44228b", null ],
    [ "mousePressEvent", "d3/db6/classWidgetLoginTitle.html#ac86b5a46833dc1f08867a51e7f4cd2c2", null ],
    [ "mouseReleaseEvent", "d3/db6/classWidgetLoginTitle.html#ae2e1db5525ed72308da5e539c00826c3", null ],
    [ "signalClose", "d3/db6/classWidgetLoginTitle.html#a64d58eca6de7c0f7606267f7c328bfcc", null ],
    [ "signalMin", "d3/db6/classWidgetLoginTitle.html#ac72ae0c6727f02a505a323edcabb0061", null ]
];