var classListWidgetItemBrowseRecord =
[
    [ "ListWidgetItemBrowseRecord", "d3/dc1/classListWidgetItemBrowseRecord.html#a9696938b495375874136e1d0eb0a0758", null ],
    [ "getBook", "d3/dc1/classListWidgetItemBrowseRecord.html#ad9b433d23da10757ae567c2c4d07fe9b", null ],
    [ "update", "d3/dc1/classListWidgetItemBrowseRecord.html#ab9110f69ef2af02ecd18febed79bf93d", null ]
];