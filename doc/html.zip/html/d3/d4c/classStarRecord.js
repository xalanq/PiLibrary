var classStarRecord =
[
    [ "ptree", "d3/d4c/classStarRecord.html#af296fe66b6b33001f02d91e874564683", null ],
    [ "xint", "d3/d4c/classStarRecord.html#afc0a727f17501890a89b1c1de8fb2035", null ],
    [ "xll", "d3/d4c/classStarRecord.html#a7082044eceab58f621d64ba60d26fa26", null ],
    [ "xstring", "d3/d4c/classStarRecord.html#a947722eb400d8136da49bbb07ff94eeb", null ],
    [ "~StarRecord", "d3/d4c/classStarRecord.html#a3ab854317dfc311bfc32aa9546ea264f", null ],
    [ "getBookid", "d3/d4c/classStarRecord.html#a2e5896bb3e37db3dbb06d6c5862d5a1d", null ],
    [ "getTime", "d3/d4c/classStarRecord.html#af1999ccdb7e7d1098181fac5cde2fb73", null ],
    [ "operator<", "d3/d4c/classStarRecord.html#a9f84fdd29819191b049d7efcfa7cf960", null ],
    [ "setBookid", "d3/d4c/classStarRecord.html#ace8e94374c1957d6995d5948b3b0d18c", null ],
    [ "setFromPtree", "d3/d4c/classStarRecord.html#a6bc027a46945be849bad7d34efc795fb", null ],
    [ "setTime", "d3/d4c/classStarRecord.html#aaa4385076601434abdffca1c3d431ac8", null ]
];