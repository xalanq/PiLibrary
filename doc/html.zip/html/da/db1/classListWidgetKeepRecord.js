var classListWidgetKeepRecord =
[
    [ "ListWidgetKeepRecord", "da/db1/classListWidgetKeepRecord.html#a6e3950a5ccea0d8f359e3892777b2da6", null ],
    [ "add", "da/db1/classListWidgetKeepRecord.html#a1a00cdcea68632c2b27db1ca2b835826", null ],
    [ "update", "da/db1/classListWidgetKeepRecord.html#a63c5ce461b960530cd415b8de3645238", null ]
];