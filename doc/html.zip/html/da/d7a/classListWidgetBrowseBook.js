var classListWidgetBrowseBook =
[
    [ "ListWidgetBrowseBook", "da/d7a/classListWidgetBrowseBook.html#ae1588640350601c412ce6121ddcfe3a8", null ],
    [ "add", "da/d7a/classListWidgetBrowseBook.html#a980ac7d8c61cc83ddd7e5cc50919d284", null ],
    [ "signalModify", "da/d7a/classListWidgetBrowseBook.html#aefa7dbc88db9ba0ab3b0bd47ae10c709", null ],
    [ "signalReady", "da/d7a/classListWidgetBrowseBook.html#a76b1580d956d39ab1a20c6beeecab8cc", null ],
    [ "slotGetBookList", "da/d7a/classListWidgetBrowseBook.html#a936312118446dead2eea7cfec8dc5c83", null ],
    [ "slotItemClicked", "da/d7a/classListWidgetBrowseBook.html#a8da28e522c704a1db612955470ba784c", null ],
    [ "update", "da/d7a/classListWidgetBrowseBook.html#a1819dc6c9cbb42a905cf71d9fd1ff04e", null ],
    [ "updateStar", "da/d7a/classListWidgetBrowseBook.html#a741d1dfa00484a5e448e2c3caf4b0547", null ]
];